from vista import vista

vista()
